package swarm.subsystems;

import swarm.infra.MessageBus;
import swarm.messages.DroneCommand;
import swarm.messages.DroneStatus;

import javax.swing.text.Position;


/**
 * Drone subsystem.
 *
 * Responsibilities (Iteration 1):
 * 1. Consults scheduler
 * 2. Simulates drone en route
 * 3. simul.ated drone putting out fire
 *
 * logic is intentionally minimal for Iteration 1.
 */
public class DroneSubsystem implements Runnable{
    private final MessageBus bus;
    private final int droneId;
    private final ZoneManager zoneManager;
    private int currentAgent;
    private Position currentPosition;

    public DroneSubsystem(MessageBus bus, int droneId, ZoneManager zoneManager) {
        this.bus = bus;
        this.droneId = droneId;
        this.zoneManager = zoneManager;
        this.currentAgent = DroneConfig.AGENT_CAPACITY_LITERS;
        this.currentPosition = DronConfig.BASE_POSITION;
    }

    @Override
    public void run() {
        // thread to handle drone commands
        new Thread(this::processMissions, "Drone-" + droneId + "-Processor").start();
    }

    /**
     * Checks for drone commands and dispatches a drone
     */
    private void processMissions() {
        try {
            while (true) {
                // 1. IDLE: Wait for work
                reportStatus(DroneState.IDLE, null);
                DroneCommand cmd = bus.droneCommands.take();
                Position target = zoneManager.getZoneCenter(cmd.zoneId());

                // 2. EN_ROUTE: Calculate flight time based on distance
                reportStatus(DroneState.EN_ROUTE, cmd.zoneId());
                long flightTime = DroneConfig.travelTimeMillis(currentPos.distanceTo(target));
                Thread.sleep(flightTime);
                currentPos = target;

                // 3. DROPPING_AGENT: Time = door cycle + flow rate
                reportStatus(DroneState.DROPPING_AGENT, cmd.zoneId());
                long dropTime = DroneConfig.dropTimeMillis(cmd.severity().litersRequired())
                        + DroneConfig.doorOpenCloseMillis();
                Thread.sleep(dropTime);
                currentAgent -= cmd.severity().litersRequired();

                // 4. RETURNING: Back to base to refill (Iteration 2 logic)
                reportStatus(DroneState.RETURNING, null);
                Thread.sleep(DroneConfig.travelTimeMillis(currentPos.distanceTo(DroneConfig.BASE_POSITION)));

                // 5. REFILLING
                reportStatus(DroneState.REFILLING, null);
                currentPos = DroneConfig.BASE_POSITION;
                currentAgent = DroneConfig.AGENT_CAPACITY_LITERS; // Refilled
                Thread.sleep(1000); // Small delay to simulate refill/landing
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void reportStatus(DroneState state, Integer zoneId) throws InterruptedException{
        bus.droneStatuses.put(new DroneStatus(droneId, state, zoneId, currentAgent));
    }
}
